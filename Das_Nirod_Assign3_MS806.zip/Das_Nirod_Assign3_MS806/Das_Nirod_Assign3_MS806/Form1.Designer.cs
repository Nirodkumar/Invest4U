﻿namespace Das_Nirod_Assign3_MS806
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.LoginButton = new System.Windows.Forms.Button();
            this.InvestmentgroupBox = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ProceedButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.P_RadioButton4 = new System.Windows.Forms.RadioButton();
            this.P_RadioButton3 = new System.Windows.Forms.RadioButton();
            this.P_RadioButton2 = new System.Windows.Forms.RadioButton();
            this.P_RadioButton1 = new System.Windows.Forms.RadioButton();
            this.DisplayButton = new System.Windows.Forms.Button();
            this.Inv_Dtl_Groupbox = new System.Windows.Forms.GroupBox();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.Phone_TextBox = new System.Windows.Forms.TextBox();
            this.Email_TextBox = new System.Windows.Forms.TextBox();
            this.Name_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.Trans_ID_Label = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AmountTextBox = new System.Windows.Forms.TextBox();
            this.AmountLabel = new System.Windows.Forms.Label();
            this.AmountGroupBox = new System.Windows.Forms.GroupBox();
            this.WelcomePanel = new System.Windows.Forms.Panel();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.DateRadioButton = new System.Windows.Forms.RadioButton();
            this.EmailRadioButton = new System.Windows.Forms.RadioButton();
            this.TransID_RadioButton = new System.Windows.Forms.RadioButton();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchTextBox = new System.Windows.Forms.TextBox();
            this.SearchResultListBox = new System.Windows.Forms.ListBox();
            this.ButtonPanel = new System.Windows.Forms.Panel();
            this.SummarButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.TotalAmountLable = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.AvgDurationLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TotalInterestlabel = new System.Windows.Forms.Label();
            this.AvgAmountLable = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Trans_ID_ListBox = new System.Windows.Forms.ListBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.InvestmentgroupBox.SuspendLayout();
            this.Inv_Dtl_Groupbox.SuspendLayout();
            this.AmountGroupBox.SuspendLayout();
            this.WelcomePanel.SuspendLayout();
            this.SearchGroupBox.SuspendLayout();
            this.ButtonPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SummaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(144, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(310, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(64, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please Insert Password";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(298, 208);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(211, 20);
            this.PasswordTextBox.TabIndex = 2;
            this.PasswordTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LoginButton
            // 
            this.LoginButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginButton.Location = new System.Drawing.Point(241, 256);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(125, 40);
            this.LoginButton.TabIndex = 3;
            this.LoginButton.Text = "Login";
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // InvestmentgroupBox
            // 
            this.InvestmentgroupBox.Controls.Add(this.label15);
            this.InvestmentgroupBox.Controls.Add(this.ProceedButton);
            this.InvestmentgroupBox.Controls.Add(this.label4);
            this.InvestmentgroupBox.Controls.Add(this.label5);
            this.InvestmentgroupBox.Controls.Add(this.label3);
            this.InvestmentgroupBox.Controls.Add(this.P_RadioButton4);
            this.InvestmentgroupBox.Controls.Add(this.P_RadioButton3);
            this.InvestmentgroupBox.Controls.Add(this.P_RadioButton2);
            this.InvestmentgroupBox.Controls.Add(this.P_RadioButton1);
            this.InvestmentgroupBox.Location = new System.Drawing.Point(12, 128);
            this.InvestmentgroupBox.Name = "InvestmentgroupBox";
            this.InvestmentgroupBox.Size = new System.Drawing.Size(574, 228);
            this.InvestmentgroupBox.TabIndex = 4;
            this.InvestmentgroupBox.TabStop = false;
            this.InvestmentgroupBox.Text = "Investment Details";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(28, 201);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(512, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "If Investment >1000000 And Period>=5 years Then Additional 25000 Bonus will be ad" +
    "ded";
            // 
            // ProceedButton
            // 
            this.ProceedButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProceedButton.Location = new System.Drawing.Point(460, 141);
            this.ProceedButton.Name = "ProceedButton";
            this.ProceedButton.Size = new System.Drawing.Size(93, 23);
            this.ProceedButton.TabIndex = 4;
            this.ProceedButton.Text = "Proceed";
            this.ProceedButton.UseVisualStyleBackColor = true;
            this.ProceedButton.Click += new System.EventHandler(this.ProceedButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Period";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(338, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Total";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(188, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Rate";
            // 
            // P_RadioButton4
            // 
            this.P_RadioButton4.AutoSize = true;
            this.P_RadioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P_RadioButton4.Location = new System.Drawing.Point(31, 157);
            this.P_RadioButton4.Name = "P_RadioButton4";
            this.P_RadioButton4.Size = new System.Drawing.Size(14, 13);
            this.P_RadioButton4.TabIndex = 2;
            this.P_RadioButton4.UseVisualStyleBackColor = true;
            // 
            // P_RadioButton3
            // 
            this.P_RadioButton3.AutoSize = true;
            this.P_RadioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P_RadioButton3.Location = new System.Drawing.Point(31, 134);
            this.P_RadioButton3.Name = "P_RadioButton3";
            this.P_RadioButton3.Size = new System.Drawing.Size(14, 13);
            this.P_RadioButton3.TabIndex = 2;
            this.P_RadioButton3.UseVisualStyleBackColor = true;
            // 
            // P_RadioButton2
            // 
            this.P_RadioButton2.AutoSize = true;
            this.P_RadioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P_RadioButton2.Location = new System.Drawing.Point(31, 109);
            this.P_RadioButton2.Name = "P_RadioButton2";
            this.P_RadioButton2.Size = new System.Drawing.Size(14, 13);
            this.P_RadioButton2.TabIndex = 2;
            this.P_RadioButton2.UseVisualStyleBackColor = true;
            // 
            // P_RadioButton1
            // 
            this.P_RadioButton1.AutoSize = true;
            this.P_RadioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P_RadioButton1.Location = new System.Drawing.Point(31, 86);
            this.P_RadioButton1.Name = "P_RadioButton1";
            this.P_RadioButton1.Size = new System.Drawing.Size(14, 13);
            this.P_RadioButton1.TabIndex = 2;
            this.P_RadioButton1.UseVisualStyleBackColor = true;
            // 
            // DisplayButton
            // 
            this.DisplayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayButton.Location = new System.Drawing.Point(448, 41);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Size = new System.Drawing.Size(93, 23);
            this.DisplayButton.TabIndex = 4;
            this.DisplayButton.Text = "Display";
            this.toolTip1.SetToolTip(this.DisplayButton, "Press To Display");
            this.DisplayButton.UseVisualStyleBackColor = true;
            this.DisplayButton.Click += new System.EventHandler(this.DisplayButton_Click);
            // 
            // Inv_Dtl_Groupbox
            // 
            this.Inv_Dtl_Groupbox.Controls.Add(this.SubmitButton);
            this.Inv_Dtl_Groupbox.Controls.Add(this.Phone_TextBox);
            this.Inv_Dtl_Groupbox.Controls.Add(this.Email_TextBox);
            this.Inv_Dtl_Groupbox.Controls.Add(this.Name_TextBox);
            this.Inv_Dtl_Groupbox.Controls.Add(this.label2);
            this.Inv_Dtl_Groupbox.Controls.Add(this.DateLabel);
            this.Inv_Dtl_Groupbox.Controls.Add(this.Trans_ID_Label);
            this.Inv_Dtl_Groupbox.Controls.Add(this.label10);
            this.Inv_Dtl_Groupbox.Controls.Add(this.label9);
            this.Inv_Dtl_Groupbox.Controls.Add(this.label8);
            this.Inv_Dtl_Groupbox.Controls.Add(this.label7);
            this.Inv_Dtl_Groupbox.Location = new System.Drawing.Point(12, 489);
            this.Inv_Dtl_Groupbox.Name = "Inv_Dtl_Groupbox";
            this.Inv_Dtl_Groupbox.Size = new System.Drawing.Size(574, 265);
            this.Inv_Dtl_Groupbox.TabIndex = 5;
            this.Inv_Dtl_Groupbox.TabStop = false;
            this.Inv_Dtl_Groupbox.Text = "Investor Details";
            // 
            // SubmitButton
            // 
            this.SubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton.Location = new System.Drawing.Point(457, 85);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(84, 37);
            this.SubmitButton.TabIndex = 3;
            this.SubmitButton.Text = "Submit";
            this.toolTip1.SetToolTip(this.SubmitButton, "Press To Submit");
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // Phone_TextBox
            // 
            this.Phone_TextBox.Location = new System.Drawing.Point(207, 179);
            this.Phone_TextBox.Name = "Phone_TextBox";
            this.Phone_TextBox.Size = new System.Drawing.Size(170, 20);
            this.Phone_TextBox.TabIndex = 2;
            this.Phone_TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Email_TextBox
            // 
            this.Email_TextBox.Location = new System.Drawing.Point(207, 144);
            this.Email_TextBox.Name = "Email_TextBox";
            this.Email_TextBox.Size = new System.Drawing.Size(170, 20);
            this.Email_TextBox.TabIndex = 2;
            this.Email_TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Name_TextBox
            // 
            this.Name_TextBox.Location = new System.Drawing.Point(207, 107);
            this.Name_TextBox.Name = "Name_TextBox";
            this.Name_TextBox.Size = new System.Drawing.Size(170, 20);
            this.Name_TextBox.TabIndex = 2;
            this.Name_TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Transaction Date";
            // 
            // DateLabel
            // 
            this.DateLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DateLabel.Location = new System.Drawing.Point(207, 74);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(170, 21);
            this.DateLabel.TabIndex = 1;
            this.DateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Trans_ID_Label
            // 
            this.Trans_ID_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Trans_ID_Label.Location = new System.Drawing.Point(207, 35);
            this.Trans_ID_Label.Name = "Trans_ID_Label";
            this.Trans_ID_Label.Size = new System.Drawing.Size(170, 21);
            this.Trans_ID_Label.TabIndex = 1;
            this.Trans_ID_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "Phone No";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "Email Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(28, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 15);
            this.label8.TabIndex = 0;
            this.label8.Text = "Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Transaction Number";
            // 
            // AmountTextBox
            // 
            this.AmountTextBox.Location = new System.Drawing.Point(271, 44);
            this.AmountTextBox.Name = "AmountTextBox";
            this.AmountTextBox.Size = new System.Drawing.Size(139, 20);
            this.AmountTextBox.TabIndex = 7;
            this.AmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AmountLabel
            // 
            this.AmountLabel.AutoSize = true;
            this.AmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountLabel.Location = new System.Drawing.Point(16, 44);
            this.AmountLabel.Name = "AmountLabel";
            this.AmountLabel.Size = new System.Drawing.Size(239, 15);
            this.AmountLabel.TabIndex = 6;
            this.AmountLabel.Text = "Please Enter Amount For Investment";
            // 
            // AmountGroupBox
            // 
            this.AmountGroupBox.Controls.Add(this.AmountTextBox);
            this.AmountGroupBox.Controls.Add(this.DisplayButton);
            this.AmountGroupBox.Controls.Add(this.AmountLabel);
            this.AmountGroupBox.Location = new System.Drawing.Point(12, 22);
            this.AmountGroupBox.Name = "AmountGroupBox";
            this.AmountGroupBox.Size = new System.Drawing.Size(574, 100);
            this.AmountGroupBox.TabIndex = 8;
            this.AmountGroupBox.TabStop = false;
            this.AmountGroupBox.Text = "Amount Details";
            // 
            // WelcomePanel
            // 
            this.WelcomePanel.Controls.Add(this.pictureBox1);
            this.WelcomePanel.Controls.Add(this.PasswordTextBox);
            this.WelcomePanel.Controls.Add(this.LoginButton);
            this.WelcomePanel.Controls.Add(this.label1);
            this.WelcomePanel.Location = new System.Drawing.Point(6, 153);
            this.WelcomePanel.Name = "WelcomePanel";
            this.WelcomePanel.Size = new System.Drawing.Size(574, 330);
            this.WelcomePanel.TabIndex = 4;
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Controls.Add(this.DateRadioButton);
            this.SearchGroupBox.Controls.Add(this.EmailRadioButton);
            this.SearchGroupBox.Controls.Add(this.TransID_RadioButton);
            this.SearchGroupBox.Controls.Add(this.SearchButton);
            this.SearchGroupBox.Controls.Add(this.SearchTextBox);
            this.SearchGroupBox.Location = new System.Drawing.Point(609, 178);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(231, 200);
            this.SearchGroupBox.TabIndex = 9;
            this.SearchGroupBox.TabStop = false;
            this.SearchGroupBox.Text = "Search";
            // 
            // DateRadioButton
            // 
            this.DateRadioButton.AutoSize = true;
            this.DateRadioButton.Location = new System.Drawing.Point(55, 74);
            this.DateRadioButton.Name = "DateRadioButton";
            this.DateRadioButton.Size = new System.Drawing.Size(100, 17);
            this.DateRadioButton.TabIndex = 2;
            this.DateRadioButton.TabStop = true;
            this.DateRadioButton.Text = "Search By Date";
            this.DateRadioButton.UseVisualStyleBackColor = true;
            // 
            // EmailRadioButton
            // 
            this.EmailRadioButton.AutoSize = true;
            this.EmailRadioButton.Location = new System.Drawing.Point(55, 51);
            this.EmailRadioButton.Name = "EmailRadioButton";
            this.EmailRadioButton.Size = new System.Drawing.Size(102, 17);
            this.EmailRadioButton.TabIndex = 2;
            this.EmailRadioButton.TabStop = true;
            this.EmailRadioButton.Text = "Search By Email";
            this.EmailRadioButton.UseVisualStyleBackColor = true;
            // 
            // TransID_RadioButton
            // 
            this.TransID_RadioButton.AutoSize = true;
            this.TransID_RadioButton.Location = new System.Drawing.Point(55, 28);
            this.TransID_RadioButton.Name = "TransID_RadioButton";
            this.TransID_RadioButton.Size = new System.Drawing.Size(145, 17);
            this.TransID_RadioButton.TabIndex = 2;
            this.TransID_RadioButton.TabStop = true;
            this.TransID_RadioButton.Text = "Search By Transaction Id";
            this.TransID_RadioButton.UseVisualStyleBackColor = true;
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(78, 148);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(75, 23);
            this.SearchButton.TabIndex = 1;
            this.SearchButton.Text = "Search";
            this.toolTip1.SetToolTip(this.SearchButton, "Press to Search Transactios");
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchTextBox
            // 
            this.SearchTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchTextBox.Location = new System.Drawing.Point(55, 113);
            this.SearchTextBox.Name = "SearchTextBox";
            this.SearchTextBox.Size = new System.Drawing.Size(123, 20);
            this.SearchTextBox.TabIndex = 0;
            this.SearchTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SearchResultListBox
            // 
            this.SearchResultListBox.FormattingEnabled = true;
            this.SearchResultListBox.HorizontalScrollbar = true;
            this.SearchResultListBox.Location = new System.Drawing.Point(609, 22);
            this.SearchResultListBox.Name = "SearchResultListBox";
            this.SearchResultListBox.Size = new System.Drawing.Size(231, 147);
            this.SearchResultListBox.TabIndex = 10;
            // 
            // ButtonPanel
            // 
            this.ButtonPanel.Controls.Add(this.SummarButton);
            this.ButtonPanel.Controls.Add(this.ExitButton);
            this.ButtonPanel.Controls.Add(this.ClearButton);
            this.ButtonPanel.Controls.Add(this.pictureBox2);
            this.ButtonPanel.Location = new System.Drawing.Point(609, 386);
            this.ButtonPanel.Name = "ButtonPanel";
            this.ButtonPanel.Size = new System.Drawing.Size(231, 368);
            this.ButtonPanel.TabIndex = 11;
            // 
            // SummarButton
            // 
            this.SummarButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummarButton.Location = new System.Drawing.Point(69, 13);
            this.SummarButton.Name = "SummarButton";
            this.SummarButton.Size = new System.Drawing.Size(109, 46);
            this.SummarButton.TabIndex = 2;
            this.SummarButton.Text = "Summary";
            this.toolTip1.SetToolTip(this.SummarButton, "Enter to view Summary");
            this.SummarButton.UseVisualStyleBackColor = true;
            this.SummarButton.Click += new System.EventHandler(this.SummarButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(69, 169);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(109, 41);
            this.ExitButton.TabIndex = 1;
            this.ExitButton.Text = "Exit";
            this.toolTip1.SetToolTip(this.ExitButton, "Press to Exit");
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(69, 94);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(109, 41);
            this.ClearButton.TabIndex = 1;
            this.ClearButton.Text = "Clear";
            this.toolTip1.SetToolTip(this.ClearButton, "Press to Clear Data");
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(16, 234);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(198, 122);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.Controls.Add(this.TotalAmountLable);
            this.SummaryGroupBox.Controls.Add(this.label14);
            this.SummaryGroupBox.Controls.Add(this.AvgDurationLabel);
            this.SummaryGroupBox.Controls.Add(this.label12);
            this.SummaryGroupBox.Controls.Add(this.TotalInterestlabel);
            this.SummaryGroupBox.Controls.Add(this.AvgAmountLable);
            this.SummaryGroupBox.Controls.Add(this.label13);
            this.SummaryGroupBox.Controls.Add(this.label11);
            this.SummaryGroupBox.Controls.Add(this.label6);
            this.SummaryGroupBox.Controls.Add(this.Trans_ID_ListBox);
            this.SummaryGroupBox.Location = new System.Drawing.Point(6, 128);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(508, 335);
            this.SummaryGroupBox.TabIndex = 12;
            this.SummaryGroupBox.TabStop = false;
            this.SummaryGroupBox.Text = "Summary";
            // 
            // TotalAmountLable
            // 
            this.TotalAmountLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalAmountLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountLable.Location = new System.Drawing.Point(333, 78);
            this.TotalAmountLable.Name = "TotalAmountLable";
            this.TotalAmountLable.Size = new System.Drawing.Size(153, 22);
            this.TotalAmountLable.TabIndex = 1;
            this.TotalAmountLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(168, 145);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(138, 15);
            this.label14.TabIndex = 1;
            this.label14.Text = "Avg Amount Invested";
            // 
            // AvgDurationLabel
            // 
            this.AvgDurationLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AvgDurationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvgDurationLabel.Location = new System.Drawing.Point(333, 273);
            this.AvgDurationLabel.Name = "AvgDurationLabel";
            this.AvgDurationLabel.Size = new System.Drawing.Size(153, 22);
            this.AvgDurationLabel.TabIndex = 1;
            this.AvgDurationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(168, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(148, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "Total Amount Invested";
            // 
            // TotalInterestlabel
            // 
            this.TotalInterestlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalInterestlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInterestlabel.Location = new System.Drawing.Point(333, 211);
            this.TotalInterestlabel.Name = "TotalInterestlabel";
            this.TotalInterestlabel.Size = new System.Drawing.Size(153, 22);
            this.TotalInterestlabel.TabIndex = 1;
            this.TotalInterestlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AvgAmountLable
            // 
            this.AvgAmountLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AvgAmountLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvgAmountLable.Location = new System.Drawing.Point(333, 146);
            this.AvgAmountLable.Name = "AvgAmountLable";
            this.AvgAmountLable.Size = new System.Drawing.Size(153, 22);
            this.AvgAmountLable.TabIndex = 1;
            this.AvgAmountLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(168, 277);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "Avg Duration";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(168, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "Total Interest Accurring";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Total Transaction ID";
            // 
            // Trans_ID_ListBox
            // 
            this.Trans_ID_ListBox.FormattingEnabled = true;
            this.Trans_ID_ListBox.Location = new System.Drawing.Point(15, 80);
            this.Trans_ID_ListBox.Name = "Trans_ID_ListBox";
            this.Trans_ID_ListBox.Size = new System.Drawing.Size(138, 225);
            this.Trans_ID_ListBox.TabIndex = 0;
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 770);
            this.Controls.Add(this.SummaryGroupBox);
            this.Controls.Add(this.ButtonPanel);
            this.Controls.Add(this.SearchResultListBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.WelcomePanel);
            this.Controls.Add(this.AmountGroupBox);
            this.Controls.Add(this.Inv_Dtl_Groupbox);
            this.Controls.Add(this.InvestmentgroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Login Page";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.InvestmentgroupBox.ResumeLayout(false);
            this.InvestmentgroupBox.PerformLayout();
            this.Inv_Dtl_Groupbox.ResumeLayout(false);
            this.Inv_Dtl_Groupbox.PerformLayout();
            this.AmountGroupBox.ResumeLayout(false);
            this.AmountGroupBox.PerformLayout();
            this.WelcomePanel.ResumeLayout(false);
            this.WelcomePanel.PerformLayout();
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            this.ButtonPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Button LoginButton;
        private System.Windows.Forms.GroupBox InvestmentgroupBox;
        private System.Windows.Forms.RadioButton P_RadioButton4;
        private System.Windows.Forms.RadioButton P_RadioButton3;
        private System.Windows.Forms.RadioButton P_RadioButton2;
        private System.Windows.Forms.RadioButton P_RadioButton1;
        private System.Windows.Forms.Button ProceedButton;
        private System.Windows.Forms.Button DisplayButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox Inv_Dtl_Groupbox;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.TextBox Phone_TextBox;
        private System.Windows.Forms.TextBox Email_TextBox;
        private System.Windows.Forms.TextBox Name_TextBox;
        private System.Windows.Forms.Label Trans_ID_Label;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox AmountTextBox;
        private System.Windows.Forms.Label AmountLabel;
        private System.Windows.Forms.GroupBox AmountGroupBox;
        private System.Windows.Forms.Panel WelcomePanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox SearchTextBox;
        private System.Windows.Forms.ListBox SearchResultListBox;
        private System.Windows.Forms.Panel ButtonPanel;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox SummaryGroupBox;
        private System.Windows.Forms.Label TotalAmountLable;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label AvgDurationLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label TotalInterestlabel;
        private System.Windows.Forms.Label AvgAmountLable;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox Trans_ID_ListBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton DateRadioButton;
        private System.Windows.Forms.RadioButton EmailRadioButton;
        private System.Windows.Forms.RadioButton TransID_RadioButton;
        private System.Windows.Forms.Button SummarButton;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

