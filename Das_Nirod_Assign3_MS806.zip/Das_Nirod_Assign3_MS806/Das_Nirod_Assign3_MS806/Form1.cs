﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Das_Nirod_Assign3_MS806
{
    public partial class MainForm : Form
    {
        //hiding groupboxes as per design for form load
        public MainForm()
        {
            InitializeComponent();
            InvestmentgroupBox.Visible = false;
            Inv_Dtl_Groupbox.Visible = false;
            AmountGroupBox.Visible = false;
            SearchGroupBox.Visible = false;
            SearchResultListBox.Visible = false;
            ButtonPanel.Visible = false;
            SummaryGroupBox.Visible = false;
        }
        //Assigning no of field varriables to use in multiple buttons and calculations throughout the application


        string Password, Name1, Email, Date;
        int P_counter = 0, Duration = 0, phoneno, TranscationID = 0;
        const decimal Int_Rate_1 = 0.005000m, Int_Rate_2 = 0.006250m, Int_Rate_3 = 0.007125m, Int_Rate_4 = 0.011250m, Int_Rate_5 = 0.006000m, Int_Rate_6 = 0.007250m, Int_Rate_7 = 0.008125m, Int_Rate_8 = 0.012500m;
        const int Duration1 = 1, Duration2 = 3, Duration3 = 5, Duration4 = 10;
        const int Period1 = 12, Period2 = 36, Period3 = 60, Period4 = 120;
        decimal Inv_amount = 0m, Bonus = 25000m, FinalValue = 0m, Total1 = 0m, Total2 = 0m, Total3 = 0m, Total4 = 0m, Total5 = 0m, Return_Investment;
        StreamWriter Outputfile;
        const string Password1= "ShowMeTheMoney#";
        const int FORMSTARTWIDTH = 650, FORMEXPANDWIDTH = 900, FORMSTARTHEIGHT = 500, FORMEXPANDHEIGHT = 800;
        //Assigning starting height while form load
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Size = new Size(FORMSTARTWIDTH, FORMSTARTHEIGHT);
        }
        private void LoginButton_Click(object sender, System.EventArgs e)
        {
            Password = PasswordTextBox.Text;
            //for checking and comparing password entered by user is same with password saved on string variable
            if (Password == Password1)
            {
                InvestmentgroupBox.Visible = true;
                //expanding form if passwors matches
                this.Size = new Size(FORMEXPANDWIDTH, FORMEXPANDHEIGHT);
                //creating a streamwriter file , use of "append" for multiple inputs
                Outputfile = File.AppendText("Invest4U.txt");
                Outputfile.Close();
            }
            else
            {
                P_counter++;
                //for defining maximum no of attempt
                if (P_counter == 4)
                {
                    MessageBox.Show("Sorry you have exhusted maximum attempt", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please enter correct password .No of attempt left " + (4 - P_counter), "Invalid password", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    PasswordTextBox.Focus();
                    PasswordTextBox.SelectAll();
                    return;

                }
            }
            AmountGroupBox.Visible = true;
            WelcomePanel.Visible = false;
            InvestmentgroupBox.Visible = false;
            SearchGroupBox.Visible = true;
            ButtonPanel.Visible = true;
            this.Text = "Investment Page";

        }
        private void DisplayButton_Click(object sender, System.EventArgs e)
        {
            //exception handeling to check and process integer value
            try
            {
                //taking input from customer
                Inv_amount = decimal.Parse(AmountTextBox.Text);
                //exception handeling to check negative integer
                if (Inv_amount > 0)
                {
                    //Use of If..Else if as requird by application to check if amount>1000000 or less and assigning interest
                    if (Inv_amount > 100000)
                    {
                        Total1 = Total(Int_Rate_5, Period1, Inv_amount);
                        Total2 = Total(Int_Rate_6, Period2, Inv_amount);
                        Total3 = Total(Int_Rate_7, Period3, Inv_amount);
                        Total4 = Total(Int_Rate_8, Period4, Inv_amount);
                        //calling method Total for the Final value in radio button text box
                        P_RadioButton1.Text = "1 Years                       0.006000%" + "                    " + Total(Int_Rate_5, Period1, Inv_amount).ToString("C2");
                        P_RadioButton2.Text = "3 Years                       0.007250%" + "                    " + Total(Int_Rate_6, Period2, Inv_amount).ToString("C2");
                        P_RadioButton3.Text = "5 Years                       0.008125%" + "                    " + Total(Int_Rate_7, Period3, Inv_amount).ToString("C2");
                        P_RadioButton4.Text = "10 Years                     0.012500%" + "                    " + Total(Int_Rate_8, Period4, Inv_amount).ToString("C2");
                    }

                    else if (Inv_amount > 0 && Inv_amount <= 100000)
                    {
                        Total1 = Total(Int_Rate_1, Period1, Inv_amount);
                        Total2 = Total(Int_Rate_2, Period2, Inv_amount);
                        Total3 = Total(Int_Rate_3, Period3, Inv_amount);
                        Total4 = Total(Int_Rate_4, Period4, Inv_amount);
                        //calling method Total for the Final value in radio button text box
                        P_RadioButton1.Text = "1 Years                       0.005000%" + "                    " + Total(Int_Rate_1, Period1, Inv_amount).ToString("C2");
                        P_RadioButton2.Text = "3 Years                       0.006250%" + "                    " + Total(Int_Rate_2, Period2, Inv_amount).ToString("C2");
                        P_RadioButton3.Text = "5 Years                       0.007125%" + "                    " + Total(Int_Rate_3, Period3, Inv_amount).ToString("C2");
                        P_RadioButton4.Text = "10 Years                     0.011250%" + "                    " + Total(Int_Rate_4, Period4, Inv_amount).ToString("C2");

                    }
                    else
                    {
                        MessageBox.Show("Please enter a Positive Integer", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        AmountTextBox.Focus();
                        AmountTextBox.SelectAll();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a poitive value", "invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    AmountTextBox.Focus();
                    AmountTextBox.SelectAll();
                    return;
                }
            }
            catch
            {
                MessageBox.Show("Please enter integer number", "invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                AmountTextBox.Focus();
                AmountTextBox.SelectAll();
                return;
            }
            InvestmentgroupBox.Visible = true;
            AmountGroupBox.Enabled = false;
            SearchGroupBox.Visible = false;
            SummarButton.Visible = false;
            SummaryGroupBox.Visible = false;
            SearchResultListBox.Visible = false;
        }
        //Use of Method to calculate total 
        private decimal Total(decimal InterestRate, int duration, decimal InterestReturn)
        {
            for (int count = 0; count < duration; count++)
            {
                InterestReturn = InterestReturn + (InterestRate * InterestReturn);
            }
            FinalValue = Math.Round(InterestReturn, 2);
            return InterestReturn;

        }
        private void ProceedButton_Click(object sender, System.EventArgs e)
        {

            //Use of If..Else if for use different radio buttons and assigning values as per required
            if (P_RadioButton1.Checked)
            {
                Duration = Duration1;
                Total5 = Math.Round(Total1, 2);

            }
            else if (P_RadioButton2.Checked)
            {
                Duration = Duration2;
                Total5 = Math.Round(Total2, 2);
            }
            else if (P_RadioButton3.Checked)
            {
                if (Inv_amount > 1000000)
                {
                    Total5 = Math.Round((Total3 + Bonus), 2);
                }
                else
                {
                    Total5 = Math.Round(Total3, 2);
                }
                Duration = Duration3;

            }
            else if (P_RadioButton4.Checked)
            {
                if (Inv_amount > 1000000)
                {
                    Total5 = Math.Round((Total4 + Bonus), 2);
                }
                else
                {
                    Total5 = Math.Round(Total4, 2);
                }
                Duration = Duration4;


            }
            //Exception Handeling to check if the user didnt click any radio buttons
            else
            {
                MessageBox.Show("Please Select an Option", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Return_Investment = Total5 - Inv_amount;
            //Use of DateTime to allocate System generated Date of traction
            DateTime Currenttime = DateTime.Now;
            Date = Currenttime.ToShortDateString();
            DateLabel.Text = Date;
            Boolean UniqueNum;
            //Generating a Random no And checking If it's Unique using do while loop and calling Unique method
            do
            {
                Random Trans_ID = new Random();
                TranscationID = Trans_ID.Next(10000000, 99999999);

                UniqueNum = IsUnique(TranscationID);

            }
            while (!UniqueNum);
            //After checking if random no is Unique , assigning it to TransactionID Label 
            Trans_ID_Label.Text = TranscationID.ToString();

            Inv_Dtl_Groupbox.Visible = true;
            InvestmentgroupBox.Enabled = false;
            AmountGroupBox.Enabled = false;
        }
        //Method to check If the random no is unique or not
        private Boolean IsUnique(int searchstring)
        {
            int TransLength = 8;
            //for Opening the text file
            StreamReader inputfile = File.OpenText("Invest4U.txt");
            while (!inputfile.EndOfStream)
            {
                if (searchstring.Equals(inputfile.ReadLine()))
                {
                    inputfile.Close();
                    return false;

                }
                for (int i = 0; i < TransLength - 1; i++)
                {
                    inputfile.ReadLine();

                }
            }
            inputfile.Close();
            //closing text file after checking uniquness in while loop


            return true;
        }
        private void SubmitButton_Click(object sender, System.EventArgs e)
        {
            
            
                string Name;
                Name = Name_TextBox.Text;
                //exception handeling to check if Name is not null
                if (Name_TextBox.Text != "")
                {
                    Name1 = Name;
                }
                else
                {
                    MessageBox.Show("Name Can't be blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Name_TextBox.Focus();
                    Name_TextBox.SelectAll();
                    return;
                }
                //exception handeling to check email 
                if (Email_TextBox.Text != "" && Email_TextBox.Text.Contains("@") && Email_TextBox.Text.Contains("."))
                {
                    Email = Email_TextBox.Text;


                }
                else
                {
                    MessageBox.Show("invalid Email Address", "invalid input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Email_TextBox.Focus();
                    Email_TextBox.SelectAll();
                    return;

                }
                //exception handeling to check length of phone no
                if (Phone_TextBox.Text.Length == 10)
                {
                    phoneno = int.Parse(Phone_TextBox.Text);
                }
                else
                {
                    MessageBox.Show("please enter only 10 digit mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Phone_TextBox.Focus();
                    Phone_TextBox.SelectAll();
                    return;
                }
                //printing result in formated message 
                DialogResult Output = MessageBox.Show("Your transaction ID is - " + TranscationID + "\n" + "Transaction Date - " + Date + "\n" + "Email ID - " + Email + "\n" + "Full Name - " + Name + "\n" + "Phone Number" + phoneno + "\n" + "Total Amount Invested - €" + Inv_amount + "\n" + "For total period - " + Duration + "\n" + "The maturity value will be - €" + Total5, "Comfirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                //To give option, if the user want to procced or not 
                if (Output == DialogResult.Yes)
                {
                    try
                    {
                        MessageBox.Show("Successful Transaction!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        StreamWriter OutputFile;
                        //to write data to text file
                        OutputFile = File.AppendText("Invest4U.txt");
                        OutputFile.WriteLine(TranscationID + "\n" + Date + "\n" + Email + "\n" + Name + "\n" + phoneno + "\n" + Inv_amount + "\n" + Duration + "\n" + Return_Investment);
                        OutputFile.Close();
                        //to back to main menu for next entry
                        AmountTextBox.Clear();
                        P_RadioButton1.Checked = false;
                        P_RadioButton2.Checked = false;
                        P_RadioButton3.Checked = false;
                        P_RadioButton4.Checked = false;
                        Name_TextBox.Clear();
                        Email_TextBox.Clear();
                        Phone_TextBox.Clear();
                        Trans_ID_Label.Text = "";
                        DateLabel.Text = "";
                        SearchTextBox.Clear();
                        SearchResultListBox.Items.Clear();
                        InvestmentgroupBox.Visible = false;
                        InvestmentgroupBox.Enabled = true;
                        Inv_Dtl_Groupbox.Visible = false;
                        Inv_Dtl_Groupbox.Enabled = true;
                        AmountGroupBox.Enabled = true;
                        SummarButton.Visible = true;
                        SearchGroupBox.Visible = true;
                        Trans_ID_ListBox.Items.Clear();
                    }
                    catch
                    {
                        MessageBox.Show("Transaction Error ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    //Message box to confirm cancellation of transaction
                    MessageBox.Show("Cancelling Investment", "Cancellation Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //To back to main menu for new input
                    AmountTextBox.Clear();
                    P_RadioButton1.Checked = false;
                    P_RadioButton2.Checked = false;
                    P_RadioButton3.Checked = false;
                    P_RadioButton4.Checked = false;
                    Name_TextBox.Clear();
                    Email_TextBox.Clear();
                    Phone_TextBox.Clear();
                    Trans_ID_Label.Text = "";
                    DateLabel.Text = "";
                    SearchTextBox.Text = "";
                    SearchResultListBox.Items.Clear();
                    InvestmentgroupBox.Visible = false;
                    InvestmentgroupBox.Enabled = true;
                    Inv_Dtl_Groupbox.Visible = false;
                    Inv_Dtl_Groupbox.Enabled = true;
                    AmountGroupBox.Enabled = true;
                    SummarButton.Visible = true;
                    SearchGroupBox.Visible = true;
                    Trans_ID_ListBox.Items.Clear();
                }

            
        }

        
        
        private void SummarButton_Click(object sender, EventArgs e)
        {
            int TotalTransactions = 0;
            decimal TotalAccuredInterest = 0m, Total_Investment=0m, TotalSumTenure = 0, i = 0;
            //opening text file
            StreamReader Outputfile = File.OpenText("Invest4U.txt");

            //to read until the file ends and assiging varriables
            while (!Outputfile.EndOfStream)
            {

                i++;
                string Line = Outputfile.ReadLine();


                if (i == 1)
                {
                    Trans_ID_ListBox.Items.Add(Line);
                    TotalTransactions++;

                }
                else if (i == 6)
                {
                    Total_Investment += int.Parse(Line);
                }
                else if (i == 7)
                {
                    TotalSumTenure += int.Parse(Line);
                }
                else if (i == 8)
                {
                    TotalAccuredInterest += decimal.Parse(Line);
                    i = 0;
                }
            }
            //calculation ofsummary data
            TotalAmountLable.Text = Total_Investment.ToString("c2");
            TotalInterestlabel.Text = (TotalAccuredInterest).ToString("c2");
            AvgAmountLable.Text = Average(Total_Investment,TotalTransactions).ToString("c2");
            AvgDurationLabel.Text = Average(TotalSumTenure,TotalTransactions).ToString();
            Outputfile.Close();
            SummaryGroupBox.Visible = true;
            
        }
        //Method for calculation of Average
        private decimal Average(decimal First_No,int Second_No)
        {
            decimal Avg;
            Avg=Math.Round( First_No / Second_No,2);
            return Avg ;
        }

        //to clear data and back to main menu
        private void ClearButton_Click(object sender, EventArgs e)
        {
            AmountTextBox.Clear();
            P_RadioButton1.Checked = false;
            P_RadioButton2.Checked = false;
            P_RadioButton3.Checked = false;
            P_RadioButton4.Checked = false;
            Name_TextBox.Clear();
            Email_TextBox.Clear();
            Phone_TextBox.Clear();
            Trans_ID_Label.Text = "";
            DateLabel.Text = "";
            InvestmentgroupBox.Visible = false;
            InvestmentgroupBox.Enabled = true;
            Inv_Dtl_Groupbox.Visible = false;
            Inv_Dtl_Groupbox.Enabled = true;
            AmountGroupBox.Enabled = true;
            SearchTextBox.Clear();
            
            Trans_ID_ListBox.Items.Clear();
            AvgAmountLable.Text = "";
            TotalAmountLable.Text = "";
            TotalInterestlabel.Text = "";
            AvgDurationLabel.Text = "";
            SearchGroupBox.Visible = true;
            SummarButton.Visible = true;
            
            SearchResultListBox.Items.Clear();
            SummaryGroupBox.Visible = false;
            TransID_RadioButton.Checked = false;
            EmailRadioButton.Checked = false;
            DateRadioButton.Checked = false;
            

        }
        //For exit from application
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void SearchButton_Click(object sender, EventArgs e)
        {
            //calling searching method
            IsSearching();


        }
        //method for searching
        private void IsSearching()
        {
                string TransactionID1 = "", Date1 = "", Email1="", Name1="", PhoneNo1="", Inv_Amount1="", Year1="", Inv_return1="";
                int TransLength = 8;
                StreamReader Outputfile = File.OpenText("Invest4U.txt");
                while (!Outputfile.EndOfStream)
                {
                  for (int i = 0; i < TransLength - 1; i++)
                  {

                    //assigning and storing varriables 
                    TransactionID1 = Outputfile.ReadLine();
                    Date1 = Outputfile.ReadLine();
                    Email1 = Outputfile.ReadLine();
                    Name1 = Outputfile.ReadLine();
                    PhoneNo1 = Outputfile.ReadLine();
                    Inv_Amount1 = Outputfile.ReadLine();
                    Year1 = Outputfile.ReadLine();
                    Inv_return1 = Outputfile.ReadLine();


                    //For exception handeling to check if any Radio Button is checked or not
                    if (TransID_RadioButton.Checked || DateRadioButton.Checked || EmailRadioButton.Checked)
                    {



                        //To compare and print if Transaction ID match
                        if (TransID_RadioButton.Checked && SearchTextBox.Text.Equals(TransactionID1))
                        {
                            SearchResultListBox.Items.Add(TransactionID1);
                            SearchResultListBox.Items.Add(Date1);
                            SearchResultListBox.Items.Add(Email1);
                            SearchResultListBox.Items.Add(Name1);
                            SearchResultListBox.Items.Add(PhoneNo1);
                            SearchResultListBox.Items.Add(Inv_Amount1);
                            SearchResultListBox.Items.Add(Year1);
                            SearchResultListBox.Items.Add(Inv_return1);
                        }
                        //To Compare and Print if Date Matched
                        else if (DateRadioButton.Checked && SearchTextBox.Text.Equals(Date1))
                        {
                            SearchResultListBox.Items.Add(TransactionID1);
                            SearchResultListBox.Items.Add(Date1);
                            SearchResultListBox.Items.Add(Email1);
                            SearchResultListBox.Items.Add(Name1);
                            SearchResultListBox.Items.Add(PhoneNo1);
                            SearchResultListBox.Items.Add(Inv_Amount1);
                            SearchResultListBox.Items.Add(Year1);
                            SearchResultListBox.Items.Add(Inv_return1);

                        }
                        //To compare and Print if Email Match
                        else if (EmailRadioButton.Checked && SearchTextBox.Text.Equals(Email1))
                        {
                            SearchResultListBox.Items.Add(TransactionID1);
                            SearchResultListBox.Items.Add(Date1);
                            SearchResultListBox.Items.Add(Email1);
                            SearchResultListBox.Items.Add(Name1);
                            SearchResultListBox.Items.Add(PhoneNo1);
                            SearchResultListBox.Items.Add(Inv_Amount1);
                            SearchResultListBox.Items.Add(Year1);
                            SearchResultListBox.Items.Add(Inv_return1);
                        }
                        //Exception handeling for empty text box
                        else if (SearchTextBox.Text == "")
                        {
                            MessageBox.Show("Search Teaxtbox can't be blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            return;
                        }
                        /*else if(!(SearchTextBox.Text.Equals(TransactionID1) || SearchTextBox.Text.Equals(Date1) || SearchTextBox.Text.Equals(Email1)))
                        /{
                          MessageBox.Show("Search Teaxtbox NOT FIND", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

                          return;

                        }*/
                    }
                    else
                    {
                        MessageBox.Show("Please Choose an option to search", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                  }




                    
                }
                Outputfile.Close();
                SearchResultListBox.Visible = true;

        }

    }
}
